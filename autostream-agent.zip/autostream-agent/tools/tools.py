"""
tools.py – Tool definitions for the AutoStream agent.

Contains:
  - mock_lead_capture : simulates a CRM/backend lead-capture API call
  - build_rag_context  : loads the local JSON knowledge base and returns
                         a formatted string that can be injected into the
                         system prompt (simple keyword-based RAG)
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path


# ---------------------------------------------------------------------------
# Knowledge-base path (resolved relative to this file so it works from
# any working directory)
# ---------------------------------------------------------------------------
_KB_PATH = Path(__file__).parent.parent / "knowledge_base" / "autostream_kb.json"


# ---------------------------------------------------------------------------
# Mock Lead Capture Tool
# ---------------------------------------------------------------------------

def mock_lead_capture(name: str, email: str, platform: str) -> dict:
    """
    Simulates posting a qualified lead to a CRM / backend system.

    In production this would be replaced by an actual HTTP POST to a
    CRM endpoint (HubSpot, Salesforce, a custom webhook, etc.).

    Args:
        name     : Full name of the lead.
        email    : Email address of the lead.
        platform : Content platform the lead uses (YouTube, Instagram, …).

    Returns:
        A dict with a status message and a mock lead_id.
    """
    # Basic validation
    if not name or not email or not platform:
        raise ValueError("All three fields (name, email, platform) are required.")

    if "@" not in email or "." not in email.split("@")[-1]:
        raise ValueError(f"'{email}' does not look like a valid email address.")

    # Simulate the "API response"
    lead_id = f"LEAD-{abs(hash(email + name)) % 100_000:05d}"
    timestamp = datetime.utcnow().isoformat(timespec="seconds") + "Z"

    result = {
        "status": "success",
        "lead_id": lead_id,
        "captured_at": timestamp,
        "data": {
            "name": name,
            "email": email,
            "platform": platform,
        },
    }

    # Console confirmation (required by the assignment spec)
    print(f"\n✅  Lead captured successfully: {name}, {email}, {platform}")
    print(f"    lead_id={lead_id}  captured_at={timestamp}\n")

    return result


# ---------------------------------------------------------------------------
# RAG Helper – Knowledge-Base Retrieval
# ---------------------------------------------------------------------------

def load_knowledge_base() -> dict:
    """Load and return the raw knowledge-base dict."""
    with open(_KB_PATH, "r", encoding="utf-8") as fh:
        return json.load(fh)


def build_rag_context(query: str = "") -> str:
    """
    Simple keyword-based retrieval over the local JSON knowledge base.

    For a production system you would replace this with a proper vector
    store (FAISS, Chroma, Pinecone, etc.) and embedding similarity search.
    Here we load the entire KB and return it as a structured text block –
    which is perfectly fine given the small size of the AutoStream KB.

    Args:
        query : (optional) the user's question – reserved for future
                semantic filtering.

    Returns:
        A formatted string ready to be injected into the LLM system prompt.
    """
    kb = load_knowledge_base()

    lines: list[str] = [
        f"=== {kb['company']} – Knowledge Base ===",
        f"Tagline: {kb['tagline']}",
        "",
        "--- PRICING PLANS ---",
    ]

    for plan in kb["plans"]:
        lines.append(f"\n• {plan['name']}  –  ${plan['price_monthly']}/month")
        lines.append(f"  Best for: {plan['best_for']}")
        lines.append("  Features:")
        for feat in plan["features"]:
            lines.append(f"    - {feat}")

    lines += ["", "--- POLICIES ---"]
    for policy in kb["policies"]:
        lines.append(f"\n• {policy['topic']}: {policy['details']}")

    lines += ["", "--- FAQs ---"]
    for faq in kb["faqs"]:
        lines.append(f"\nQ: {faq['question']}")
        lines.append(f"A: {faq['answer']}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Quick self-test
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print(build_rag_context())
    print("\n--- Testing lead capture ---")
    mock_lead_capture("Jane Doe", "jane@example.com", "YouTube")
