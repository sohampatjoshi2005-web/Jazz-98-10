"""
tests/test_agent.py  –  Unit & integration tests for the AutoStream agent.

Run with:  pytest tests/ -v
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
from langchain_core.messages import HumanMessage, AIMessage

from tools.tools import (
    mock_lead_capture,
    build_rag_context,
    load_knowledge_base,
)
from agent.graph import (
    classify_intent,
    extract_lead_info_from_history,
    AgentState,
)


# ---------------------------------------------------------------------------
# Knowledge-base tests
# ---------------------------------------------------------------------------

class TestKnowledgeBase:
    def test_kb_loads(self):
        kb = load_knowledge_base()
        assert kb["company"] == "AutoStream"
        assert len(kb["plans"]) == 2

    def test_kb_has_basic_plan(self):
        kb = load_knowledge_base()
        names = [p["name"] for p in kb["plans"]]
        assert "Basic Plan" in names

    def test_kb_has_pro_plan(self):
        kb = load_knowledge_base()
        names = [p["name"] for p in kb["plans"]]
        assert "Pro Plan" in names

    def test_rag_context_contains_prices(self):
        ctx = build_rag_context()
        assert "$29" in ctx
        assert "$79" in ctx

    def test_rag_context_contains_policies(self):
        ctx = build_rag_context()
        assert "7 days" in ctx.lower() or "7-day" in ctx.lower()

    def test_rag_context_contains_features(self):
        ctx = build_rag_context()
        assert "4K" in ctx or "4k" in ctx.lower()
        assert "AI captions" in ctx or "captions" in ctx.lower()


# ---------------------------------------------------------------------------
# Lead capture tool tests
# ---------------------------------------------------------------------------

class TestMockLeadCapture:
    def test_successful_capture(self, capsys):
        result = mock_lead_capture("Alice Smith", "alice@example.com", "YouTube")
        captured = capsys.readouterr()
        assert result["status"] == "success"
        assert result["data"]["name"] == "Alice Smith"
        assert "alice@example.com" in captured.out
        assert "Lead captured successfully" in captured.out

    def test_lead_id_generated(self):
        result = mock_lead_capture("Bob Jones", "bob@test.io", "TikTok")
        assert result["lead_id"].startswith("LEAD-")

    def test_missing_email_raises(self):
        with pytest.raises(ValueError):
            mock_lead_capture("Jane", "", "Instagram")

    def test_invalid_email_raises(self):
        with pytest.raises(ValueError):
            mock_lead_capture("Jane", "not-an-email", "Instagram")

    def test_missing_name_raises(self):
        with pytest.raises(ValueError):
            mock_lead_capture("", "jane@test.com", "Instagram")


# ---------------------------------------------------------------------------
# Intent classifier tests
# ---------------------------------------------------------------------------

class TestIntentClassifier:
    def _state(self, text: str) -> AgentState:
        return AgentState(
            messages=[HumanMessage(content=text)],
            intent="unknown",
            lead_info={},
            lead_captured=False,
        )

    def test_sign_up_intent(self):
        result = classify_intent(self._state("I want to sign up for the Pro plan"))
        assert result["intent"] == "high_intent"

    def test_pricing_inquiry(self):
        result = classify_intent(self._state("What are your pricing plans?"))
        assert result["intent"] == "product_inquiry"

    def test_greeting(self):
        result = classify_intent(self._state("Hi"))
        assert result["intent"] == "greeting"

    def test_subscribe_is_high_intent(self):
        result = classify_intent(self._state("I'd like to subscribe to AutoStream"))
        assert result["intent"] == "high_intent"

    def test_refund_question(self):
        result = classify_intent(self._state("What is your refund policy?"))
        assert result["intent"] == "product_inquiry"

    def test_buy_is_high_intent(self):
        result = classify_intent(self._state("I want to buy the Pro plan for my YouTube channel"))
        assert result["intent"] == "high_intent"


# ---------------------------------------------------------------------------
# Lead info extraction tests
# ---------------------------------------------------------------------------

class TestLeadInfoExtraction:
    def test_email_extracted(self):
        msgs = [HumanMessage(content="Sure, my email is john@example.com")]
        info = extract_lead_info_from_history(msgs)
        assert info.get("email") == "john@example.com"

    def test_platform_extracted(self):
        msgs = [HumanMessage(content="I create content on YouTube mainly")]
        info = extract_lead_info_from_history(msgs)
        assert info.get("platform") == "Youtube" or info.get("platform") == "YouTube"

    def test_name_extracted_my_name_is(self):
        msgs = [HumanMessage(content="My name is Sarah Connor")]
        info = extract_lead_info_from_history(msgs)
        assert info.get("name") == "Sarah Connor"

    def test_name_extracted_im(self):
        msgs = [HumanMessage(content="I'm John Doe and I'd like to sign up")]
        info = extract_lead_info_from_history(msgs)
        assert info.get("name") in ("John Doe", None)   # heuristic may miss some

    def test_all_fields_multi_turn(self):
        msgs = [
            HumanMessage(content="My name is Alice Brown"),
            HumanMessage(content="My email is alice@brown.io"),
            HumanMessage(content="I post on Instagram"),
        ]
        info = extract_lead_info_from_history(msgs)
        assert info.get("email") == "alice@brown.io"
        assert info.get("platform") == "Instagram"
