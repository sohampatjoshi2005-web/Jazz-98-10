"""
main.py  –  CLI entry-point for the AutoStream conversational AI agent.

Run:
    python main.py

Type 'exit' or 'quit' to end the session.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Make sure sibling packages are importable regardless of CWD
sys.path.insert(0, str(Path(__file__).parent))

from langchain_core.messages import HumanMessage, AIMessage

from agent.graph import get_graph, AgentState


# ANSI colour codes (graceful fallback on Windows)
try:
    import ctypes
    ctypes.windll.kernel32.SetConsoleMode(ctypes.windll.kernel32.GetStdHandle(-11), 7)
except Exception:
    pass

CYAN  = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RESET = "\033[0m"
BOLD  = "\033[1m"


def print_banner() -> None:
    print(f"""
{BOLD}{CYAN}╔══════════════════════════════════════════════╗
║   AutoStream AI Sales Agent  –  Powered by   ║
║   LangGraph + Claude Haiku                    ║
╚══════════════════════════════════════════════╝{RESET}
Type {YELLOW}'exit'{RESET} or {YELLOW}'quit'{RESET} to end the session.
──────────────────────────────────────────────
""")


def run_chat() -> None:
    print_banner()

    graph = get_graph()

    # Initial state
    state: AgentState = {
        "messages": [],
        "intent": "unknown",
        "lead_info": {},
        "lead_captured": False,
    }

    # Kick off with the agent greeting the user
    print(f"{GREEN}Aria (AutoStream){RESET}: Hi there! 👋 I'm Aria, your AutoStream assistant. "
          f"I can help you explore our plans, answer questions, or get you signed up. "
          f"What can I help you with today?\n")

    while True:
        try:
            user_input = input(f"{CYAN}You{RESET}: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\n\nGoodbye! 👋")
            break

        if not user_input:
            continue

        if user_input.lower() in {"exit", "quit", "bye", "goodbye"}:
            print(f"\n{GREEN}Aria{RESET}: Thanks for chatting! Have a great day 🎬\n")
            break

        # Append user message and invoke the graph
        state["messages"] = list(state["messages"]) + [HumanMessage(content=user_input)]

        result = graph.invoke(state)

        # Merge returned state
        state = {**state, **result}

        # Print the latest AI message (skip [LEAD_READY] sentinel lines)
        last_ai = next(
            (m for m in reversed(state["messages"]) if isinstance(m, AIMessage)),
            None,
        )
        if last_ai:
            reply = last_ai.content.replace("[LEAD_READY]", "").strip()
            print(f"\n{GREEN}Aria{RESET}: {reply}\n")

        # Show detected intent in debug mode (set DEBUG=1)
        import os
        if os.environ.get("DEBUG"):
            info = state.get("lead_info", {})
            print(f"  {YELLOW}[DEBUG] intent={state.get('intent')}  "
                  f"lead_info={info}  captured={state.get('lead_captured')}{RESET}\n")

        if state.get("lead_captured"):
            print(f"{YELLOW}✅  Lead successfully captured. Session complete!{RESET}\n")
            break


if __name__ == "__main__":
    run_chat()
