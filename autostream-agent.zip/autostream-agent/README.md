# AutoStream AI Sales Agent

> **Machine Learning Intern Assignment – ServiceHive / Inflx**  
> A LangGraph-powered conversational AI agent that converts social media conversations into qualified leads.

---

## Table of Contents
1. [Project Overview](#project-overview)  
2. [How to Run Locally](#how-to-run-locally)  
3. [Project Structure](#project-structure)  
4. [Architecture Explanation](#architecture-explanation)  
5. [WhatsApp Deployment via Webhooks](#whatsapp-deployment-via-webhooks)  
6. [Running Tests](#running-tests)  
7. [Switching LLM Providers](#switching-llm-providers)

---

## Project Overview

This agent acts as **Aria**, a sales assistant for **AutoStream** – a fictional SaaS that provides automated video editing tools for content creators.

**Capabilities:**
- ✅ Intent identification (greeting / product inquiry / high-intent lead)
- ✅ RAG-powered Q&A from a local JSON knowledge base (pricing, policies, FAQs)
- ✅ Multi-turn memory across 5–6+ conversation turns using LangGraph state
- ✅ Lead qualification: collects Name, Email, and Creator Platform conversationally
- ✅ Tool execution: calls `mock_lead_capture()` only after all three fields are confirmed

---

## How to Run Locally

### Prerequisites
- Python 3.9 or higher
- An Anthropic API key (or OpenAI / Google key – see [Switching LLM Providers](#switching-llm-providers))

### 1. Clone the repository
```bash
git clone https://github.com/<your-username>/autostream-agent.git
cd autostream-agent
```

### 2. Create and activate a virtual environment
```bash
python -m venv .venv
# macOS / Linux
source .venv/bin/activate
# Windows
.venv\Scripts\activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Set your API key

**Option A – environment variable (recommended):**
```bash
export ANTHROPIC_API_KEY=sk-ant-...          # macOS/Linux
set ANTHROPIC_API_KEY=sk-ant-...             # Windows CMD
$env:ANTHROPIC_API_KEY="sk-ant-..."          # PowerShell
```

**Option B – `.env` file:**
```
# .env
ANTHROPIC_API_KEY=sk-ant-...
```
Then add `from dotenv import load_dotenv; load_dotenv()` at the top of `main.py`.

### 5. Run the agent
```bash
python main.py
```

**Optional debug mode** (shows detected intent and collected lead fields after each turn):
```bash
DEBUG=1 python main.py
```

### Example conversation
```
You: Hi, what plans do you offer?
Aria: We have two plans – Basic ($29/month) and Pro ($79/month)...

You: I want to try the Pro plan for my YouTube channel
Aria: Great choice! Could I get your name to get you started?

You: My name is Alex Rivera
Aria: Nice to meet you, Alex! What email should I use?

You: alex@rivera.io
Aria: Perfect! And you mentioned YouTube – I'll use that as your platform.
      [internally triggers mock_lead_capture]
      🎉 You're all set, Alex! Your reference ID is LEAD-84231...
```

---

## Project Structure

```
autostream-agent/
├── main.py                          # CLI entry-point and chat loop
├── requirements.txt
├── README.md
├── knowledge_base/
│   └── autostream_kb.json           # Local RAG knowledge base
├── agent/
│   ├── __init__.py
│   └── graph.py                     # LangGraph state, nodes, edges, graph
├── tools/
│   ├── __init__.py
│   └── tools.py                     # mock_lead_capture + RAG helpers
└── tests/
    ├── __init__.py
    └── test_agent.py                # pytest unit & integration tests
```

---

## Architecture Explanation

### Why LangGraph?

LangGraph was chosen over a simple chain or a vanilla LangChain agent for three key reasons:

1. **Explicit state machine** – The agent's behaviour is modelled as a directed graph with three nodes (`classify → respond → capture_lead`). Each node has a single responsibility, making the flow easy to reason about, test, and extend. Adding new capabilities (e.g., an upsell node, a support-escalation node) requires adding a node and a conditional edge rather than rewriting prompt logic.

2. **Persistent, typed state** – `AgentState` is a `TypedDict` that carries the full message history, the detected intent, incrementally-collected lead fields, and a `lead_captured` flag. LangGraph's `add_messages` reducer appends new messages rather than replacing the list, so the agent retains full conversational memory across any number of turns with zero extra code.

3. **Conditional routing** – The `should_capture` edge function enforces the business rule *"never trigger the lead tool prematurely"* in a single, auditable location. The tool fires if and only if the LLM emits the `[LEAD_READY]` sentinel **and** all three lead fields have been extracted from the conversation – a double-safety mechanism.

### State Management

```
AgentState
├── messages        ← full history (HumanMessage / AIMessage), appended by add_messages
├── intent          ← latest classified intent (updated each turn by classify node)
├── lead_info       ← dict of {name?, email?, platform?} extracted across all turns
└── lead_captured   ← boolean; once True the session ends
```

The `classify` node runs a fast heuristic check (keyword matching) and assigns one of four intents. The `respond` node calls the LLM with the system prompt (which injects the RAG context) and the full message history. After each LLM reply, `extract_lead_info_from_history` scans all human messages with regex patterns to incrementally build the `lead_info` dict, so the agent never loses data even if the user volunteers their email two turns before being asked.

### RAG Pipeline

The knowledge base (`autostream_kb.json`) is loaded once at startup and serialised into a structured text block that is injected directly into the system prompt. This is a **prompt-stuffing** approach to RAG, which is appropriate here given the small KB size (<2 KB). For a production knowledge base (hundreds of documents), the same interface would be backed by a vector store (FAISS, Chroma, Pinecone) with embedding-based similarity retrieval.

---

## WhatsApp Deployment via Webhooks

Integrating this agent with WhatsApp using the **WhatsApp Business API (Meta Cloud API)** involves the following steps:

### 1. Set up Meta App and WhatsApp Business Account
- Create a Meta Developer app at [developers.facebook.com](https://developers.facebook.com).
- Enable the **WhatsApp** product and obtain a **Phone Number ID** and **Access Token**.

### 2. Create a Webhook endpoint
Deploy a small **FastAPI** (or Flask) server that exposes two routes:

```python
from fastapi import FastAPI, Request
import httpx, os, json

app = FastAPI()
sessions = {}   # in-memory; replace with Redis in production

@app.get("/webhook")
async def verify(hub_mode, hub_verify_token, hub_challenge):
    """Meta verification handshake."""
    if hub_verify_token == os.environ["WHATSAPP_VERIFY_TOKEN"]:
        return int(hub_challenge)
    return {"error": "invalid token"}, 403

@app.post("/webhook")
async def receive_message(request: Request):
    body = await request.json()
    message = body["entry"][0]["changes"][0]["value"]["messages"][0]
    sender  = message["from"]           # WhatsApp phone number
    text    = message["text"]["body"]

    # Retrieve or create session state for this sender
    state = sessions.get(sender, initial_state())
    state["messages"].append(HumanMessage(content=text))

    result = graph.invoke(state)
    sessions[sender] = {**state, **result}

    reply = get_last_ai_message(sessions[sender])
    await send_whatsapp_message(sender, reply)
    return {"status": "ok"}
```

### 3. Register the webhook with Meta
In the Meta Developer Dashboard, set the webhook URL to `https://your-domain.com/webhook` and choose the `messages` subscription field.

### 4. Session persistence
Replace the in-memory `sessions` dict with **Redis** (using `redis-py`) so state survives server restarts and scales across multiple workers.

### 5. Deploy
Host the FastAPI app on any cloud (Railway, Render, AWS Lambda + API Gateway, etc.) behind HTTPS. WhatsApp requires a verified SSL certificate on the webhook URL.

### Flow summary
```
User on WhatsApp
      │  (sends message)
      ▼
Meta Cloud API  ──POST──▶  /webhook  (FastAPI)
                                │
                                ▼
                        LangGraph graph.invoke()
                                │
                                ▼
                     send_whatsapp_message(reply)
                                │
                                ▼
                        User sees reply on WhatsApp
```

---

## Running Tests

```bash
pytest tests/ -v
# With coverage report:
pytest tests/ -v --cov=. --cov-report=term-missing
```

---

## Switching LLM Providers

The LLM is initialised in `agent/graph.py`. To switch providers:

**GPT-4o-mini (OpenAI):**
```python
from langchain_openai import ChatOpenAI
llm = ChatOpenAI(model="gpt-4o-mini", api_key=os.environ["OPENAI_API_KEY"])
```

**Gemini 1.5 Flash (Google):**
```python
from langchain_google_genai import ChatGoogleGenerativeAI
llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash", google_api_key=os.environ["GOOGLE_API_KEY"])
```

Update `requirements.txt` accordingly (`openai` or `google-generativeai`).
