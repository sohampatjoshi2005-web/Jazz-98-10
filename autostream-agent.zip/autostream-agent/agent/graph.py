"""
agent/graph.py  –  LangGraph-powered AutoStream conversational agent.

Architecture overview
─────────────────────
State
  AgentState holds the full conversation history plus three tracking
  fields: intent, lead_info, and lead_captured.

Nodes
  ┌─────────────┐     ┌──────────────┐     ┌────────────────┐
  │  classify   │────▶│   respond    │────▶│  capture_lead  │
  │  (intent)   │     │  (LLM reply) │     │  (tool call)   │
  └─────────────┘     └──────────────┘     └────────────────┘

Edges
  classify  →  respond  (always)
  respond   →  capture_lead   (only when intent == HIGH_INTENT and all
                                three lead fields collected)
  respond   →  END            (all other cases)
  capture_lead → END
"""

from __future__ import annotations

import os
import re
from typing import Annotated, Literal, TypedDict

from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from langchain_anthropic import ChatAnthropic
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages

from tools import build_rag_context, mock_lead_capture


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

class LeadInfo(TypedDict, total=False):
    name: str
    email: str
    platform: str


class AgentState(TypedDict):
    # Full message history – LangGraph's add_messages reducer appends new
    # messages rather than replacing the list (safe for multi-turn memory).
    messages: Annotated[list[BaseMessage], add_messages]

    # Detected intent for the *latest* user turn
    intent: Literal["greeting", "product_inquiry", "high_intent", "unknown"]

    # Incrementally collected lead fields
    lead_info: LeadInfo

    # Set to True once mock_lead_capture has been called successfully
    lead_captured: bool


# ---------------------------------------------------------------------------
# LLM
# ---------------------------------------------------------------------------

def _get_llm() -> ChatAnthropic:
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise EnvironmentError(
            "ANTHROPIC_API_KEY environment variable is not set.\n"
            "Export it before running:  export ANTHROPIC_API_KEY=sk-ant-..."
        )
    return ChatAnthropic(
        model="claude-haiku-4-5",
        api_key=api_key,
        temperature=0.3,
        max_tokens=512,
    )


LLM = None  # lazy-init so import doesn't fail without the key


def get_llm() -> ChatAnthropic:
    global LLM
    if LLM is None:
        LLM = _get_llm()
    return LLM


# ---------------------------------------------------------------------------
# System prompt factory
# ---------------------------------------------------------------------------

_RAG_CONTEXT = build_rag_context()   # loaded once at import time

SYSTEM_PROMPT_TEMPLATE = """\
You are Aria, the friendly and knowledgeable sales assistant for AutoStream – \
an AI-powered video editing SaaS for content creators.

Your goals:
1. Greet users warmly and answer questions about AutoStream's plans and policies.
2. Use ONLY the information in the Knowledge Base below – never invent prices or features.
3. Detect when a user is ready to sign up (high intent) and collect their details.
4. Collect Name, Email, and Creator Platform (e.g. YouTube) ONE AT A TIME,
   in a natural conversational flow. Do NOT ask for all three at once.
5. Once all three pieces of information have been confirmed, say exactly:
   [LEAD_READY] and nothing else on that line, then continue normally.
   This token is used internally – do not explain it to the user.
6. Never call the lead-capture tool before all three values are confirmed.

Tone: friendly, concise, helpful. Avoid jargon. Keep replies under 120 words.

{rag_context}
"""


def build_system_prompt() -> SystemMessage:
    return SystemMessage(content=SYSTEM_PROMPT_TEMPLATE.format(rag_context=_RAG_CONTEXT))


# ---------------------------------------------------------------------------
# Intent classifier (lightweight – uses keyword heuristics first, LLM as
# fallback so we don't burn tokens on obvious cases)
# ---------------------------------------------------------------------------

_HIGH_INTENT_KEYWORDS = {
    "sign up", "signup", "subscribe", "buy", "purchase", "get started",
    "start trial", "try pro", "i want", "i'd like", "let's do it",
    "where do i pay", "how do i pay", "enroll", "register",
}

_GREETING_KEYWORDS = {"hi", "hello", "hey", "howdy", "good morning",
                       "good evening", "good afternoon", "what's up", "yo"}


def classify_intent(state: AgentState) -> AgentState:
    """
    Node: classify the intent of the most recent human message.
    Updates state['intent'] in-place (returns partial state update).
    """
    last_human = next(
        (m for m in reversed(state["messages"]) if isinstance(m, HumanMessage)),
        None,
    )
    if last_human is None:
        return {"intent": "unknown"}

    text = last_human.content.lower().strip()

    # Fast-path heuristics
    if any(kw in text for kw in _HIGH_INTENT_KEYWORDS):
        return {"intent": "high_intent"}

    if len(text.split()) <= 4 and any(kw in text for kw in _GREETING_KEYWORDS):
        return {"intent": "greeting"}

    if any(kw in text for kw in ("price", "pricing", "cost", "plan", "feature",
                                   "refund", "support", "4k", "resolution",
                                   "how much", "upgrade", "trial", "free")):
        return {"intent": "product_inquiry"}

    return {"intent": "product_inquiry"}   # safe default


# ---------------------------------------------------------------------------
# Lead info extractor  (heuristic – parses LLM replies for collected data)
# ---------------------------------------------------------------------------

_EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}")
_PLATFORM_KEYWORDS = [
    "youtube", "instagram", "tiktok", "facebook", "twitter", "linkedin",
    "twitch", "snapchat", "pinterest", "x.com",
]


def extract_lead_info_from_history(messages: list[BaseMessage]) -> LeadInfo:
    """
    Walk the conversation history and pull out any lead fields that the
    user has explicitly provided. We look in *human* messages only to
    avoid the agent confusing its own questions for answers.
    """
    info: LeadInfo = {}
    human_texts = [m.content for m in messages if isinstance(m, HumanMessage)]
    full_human = " ".join(human_texts).lower()

    # Email
    match = _EMAIL_RE.search(full_human)
    if match:
        info["email"] = match.group(0)

    # Platform
    for kw in _PLATFORM_KEYWORDS:
        if kw in full_human:
            info["platform"] = kw.capitalize()
            break

    # Name – hard to extract reliably from free text; look for patterns like
    # "my name is X", "I'm X", "call me X", "it's X"
    name_patterns = [
        r"my name is ([A-Z][a-z]+(?: [A-Z][a-z]+)?)",
        r"i(?:'m| am) ([A-Z][a-z]+(?: [A-Z][a-z]+)?)",
        r"call me ([A-Z][a-z]+(?: [A-Z][a-z]+)?)",
        r"it'?s ([A-Z][a-z]+(?: [A-Z][a-z]+)?)",
        r"name'?s ([A-Z][a-z]+(?: [A-Z][a-z]+)?)",
    ]
    for pattern in name_patterns:
        m = re.search(pattern, " ".join(human_texts))
        if m:
            info["name"] = m.group(1)
            break

    return info


# ---------------------------------------------------------------------------
# Respond node  –  calls the LLM and updates state
# ---------------------------------------------------------------------------

def respond(state: AgentState) -> AgentState:
    """
    Node: generate the agent's reply using the full conversation history.
    Also updates lead_info by scanning the conversation.
    """
    llm = get_llm()

    # Always prepend the system prompt
    messages_to_send = [build_system_prompt()] + list(state["messages"])

    ai_message: AIMessage = llm.invoke(messages_to_send)

    # Update lead info from the full conversation so far
    updated_lead_info = extract_lead_info_from_history(
        list(state["messages"]) + [ai_message]
    )
    # Merge with existing (don't overwrite already-collected fields)
    merged_lead_info = {**state.get("lead_info", {}), **updated_lead_info}

    return {
        "messages": [ai_message],
        "lead_info": merged_lead_info,
    }


# ---------------------------------------------------------------------------
# Lead-capture node  –  calls the mock tool
# ---------------------------------------------------------------------------

def capture_lead(state: AgentState) -> AgentState:
    """
    Node: call mock_lead_capture once all three lead fields are present.
    Appends a confirmation AI message to the conversation.
    """
    info = state.get("lead_info", {})
    result = mock_lead_capture(
        name=info.get("name", ""),
        email=info.get("email", ""),
        platform=info.get("platform", ""),
    )

    confirmation = AIMessage(
        content=(
            f"🎉 You're all set, {info.get('name', 'there')}! "
            f"I've registered your interest in AutoStream Pro. "
            f"Your reference ID is **{result['lead_id']}**. "
            f"Our team will reach out to {info.get('email')} shortly. "
            f"Happy creating on {info.get('platform', 'your platform')}! 🚀"
        )
    )

    return {
        "messages": [confirmation],
        "lead_captured": True,
    }


# ---------------------------------------------------------------------------
# Routing logic
# ---------------------------------------------------------------------------

def should_capture(state: AgentState) -> Literal["capture_lead", "__end__"]:
    """
    After `respond`, decide whether to trigger the lead-capture node.

    Conditions (ALL must be true):
    1. Lead not already captured.
    2. Intent is high_intent.
    3. All three lead fields are collected.
    4. The last AI message contains the [LEAD_READY] sentinel.
    """
    if state.get("lead_captured"):
        return "__end__"

    last_ai = next(
        (m for m in reversed(state["messages"]) if isinstance(m, AIMessage)),
        None,
    )
    if last_ai and "[LEAD_READY]" in last_ai.content:
        info = state.get("lead_info", {})
        if info.get("name") and info.get("email") and info.get("platform"):
            return "capture_lead"

    return "__end__"


# ---------------------------------------------------------------------------
# Graph assembly
# ---------------------------------------------------------------------------

def build_graph() -> StateGraph:
    builder = StateGraph(AgentState)

    builder.add_node("classify", classify_intent)
    builder.add_node("respond", respond)
    builder.add_node("capture_lead", capture_lead)

    builder.set_entry_point("classify")
    builder.add_edge("classify", "respond")
    builder.add_conditional_edges(
        "respond",
        should_capture,
        {"capture_lead": "capture_lead", "__end__": END},
    )
    builder.add_edge("capture_lead", END)

    return builder.compile()


# Singleton compiled graph
GRAPH = None


def get_graph():
    global GRAPH
    if GRAPH is None:
        GRAPH = build_graph()
    return GRAPH
